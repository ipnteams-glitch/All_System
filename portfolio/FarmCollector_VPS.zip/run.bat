@echo off
cd /d "%~dp0"
FarmCollector.exe --loop 30
