Farm Collector - ติดตั้งบน VPS (ง่าย 3 ขั้น)
=================================================

** ไม่ต้องติดตั้ง Python **

ในโฟลเดอร์นี้:
  - FarmCollector.exe
  - FarmReporter.ex5
  - config.local.json   <-- ใส่ TOKEN ของคุณ (ขั้นที่ 1)
  - install.bat / run.bat


ขั้นที่ 1 : ใส่ TOKEN ของคุณ
  - เข้าเว็บ  www.forexcool.com/portfolio  (ผ่านปุ่ม Portfolio ในระบบ)
  - กดหัวข้อ "ตัวเก็บข้อมูล VPS (Collector)" -> คัดลอก Token
  - เปิด config.local.json ด้วย Notepad -> วาง Token -> บันทึก:
      { "TOKEN": "<Token ของคุณ>" }


ขั้นที่ 2 : ก็อปโฟลเดอร์นี้ไปวางบน VPS (เช่น C:\FarmCollector\)
  -> ดับเบิลคลิก  install.bat
  (ก็อป EA เข้าทุก terminal + ตั้ง autostart + เริ่มรัน)


ขั้นที่ 3 : ใน MetaTrader 5 (ทุก terminal)
  1) Navigator > Expert Advisors > คลิกขวา > Refresh
  2) ลาก  SGH\FarmReporter  ลง 1 chart
  3) กรอก UserEmail = อีเมลที่ใช้ login เว็บ (ต้องตรงกับ Token)
     (FixBalance = ทุน ถ้าต้องการ, เว้น 0 = ใช้ balance จริง)
  4) OK แล้วเปิด AutoTrading (ปุ่มเขียว)

เสร็จ! ข้อมูลขึ้นเว็บภายใน ~1-2 นาที


ตรวจสอบ: ดับเบิลคลิก FarmCollector.exe -> เห็น "live account(s)" + "backend: ok"

หมายเหตุ:
  - Token เขียนได้เฉพาะพอร์ตของอีเมลคุณ ปลอดภัยแม้หลุด
  - MT5 + collector ต้องเปิดค้างตลอด
  - ถ้า FarmCollector.exe หายหลังแตก zip = antivirus ลบ -> Restore + Add exclusion
