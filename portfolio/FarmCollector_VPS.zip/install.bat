@echo off
setlocal enabledelayedexpansion
echo ============================================
echo   Farm Collector - VPS Installer
echo ============================================
echo.
echo [1/3] Copying FarmReporter EA into all MT5 terminals...
set COUNT=0
for /d %%T in ("%APPDATA%\MetaQuotes\Terminal\*") do (
  if exist "%%T\MQL5\Experts" (
    if not exist "%%T\MQL5\Experts\SGH" mkdir "%%T\MQL5\Experts\SGH"
    copy /Y "%~dp0FarmReporter.ex5" "%%T\MQL5\Experts\SGH\" >nul
    set /a COUNT+=1
    echo     copied to %%~nxT
  )
)
echo     Done. !COUNT! terminal^(s^).
echo.
echo [2/3] Setting collector to auto-start on logon...
schtasks /Create /TN "FarmCollector" /TR "\"%~dp0FarmCollector.exe\" --loop 30" /SC ONLOGON /RL LIMITED /F >nul 2>&1
if errorlevel 1 (echo     WARN: could not create task - try running install.bat as Administrator) else (echo     Done.)
echo.
echo [3/3] Starting collector now...
start "FarmCollector" "%~dp0FarmCollector.exe" --loop 30
echo     Running.
echo.
echo ============================================
echo   NEXT - do this inside MetaTrader 5:
echo   1. Navigator - right-click Expert Advisors - Refresh
echo   2. Drag  SGH\FarmReporter  onto ONE chart per terminal
echo   3. Type UserEmail, click OK, turn AutoTrading ON
echo ============================================
pause
